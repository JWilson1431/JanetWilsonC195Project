package model;

public interface AlertInterface {
    String getAlert(String s);
}
