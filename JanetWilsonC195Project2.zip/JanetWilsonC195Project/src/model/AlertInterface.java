package model;

import javafx.scene.control.Alert;

public interface AlertInterface {
    String getAlert(String s);
}
