package model;

public interface DisplayMessage {
    String displayMessage();
}
